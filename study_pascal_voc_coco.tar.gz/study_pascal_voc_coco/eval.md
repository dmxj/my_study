## 模型评估
VOC 评估：
官方的：
https://github.com/rbgirshick/py-faster-rcnn/blob/master/lib/datasets/voc_eval.py
https://github.com/facebookresearch/maskrcnn-benchmark/blob/master/maskrcnn_benchmark/data/datasets/evaluation/voc/voc_eval.py#L48

gluonCV版本：
https://github.com/dmlc/gluon-cv/blob/master/gluoncv/utils/metrics/voc_detection.py

COCO 评估：
https://github.com/facebookresearch/maskrcnn-benchmark/blob/master/maskrcnn_benchmark/data/datasets/evaluation/coco/coco_eval.py

gluonCV版本：
https://github.com/dmlc/gluon-cv/blob/master/gluoncv/utils/metrics/coco_detection.py

MaskRCNN_benckmark 关于voc评估的讨论：
https://github.com/facebookresearch/maskrcnn-benchmark/issues/258

MAP的计算方式：
https://www.zhihu.com/question/53405779
https://medium.com/@jonathan_hui/map-mean-average-precision-for-object-detection-45c121a31173


